


const tabItems = document.querySelectorAll(".tab-item");
const contentItems = document.querySelectorAll(".content-item");

const clearActiveClass = (element, className = "is-active") => {
    element.forEach((item) => item.classList.remove(`${className}`));
};

const setActiveClass = (element, index, className = "is-active") => {
    element[index].classList.add(`${className}`);
};

const checkoutTabs = (item, index) => {
    item.addEventListener("click", () => {
        if (item.classList.contains("is-active")) return;

        const currentItem = index;

        clearActiveClass(tabItems);
        clearActiveClass(contentItems);

        setActiveClass(tabItems, currentItem);
        setActiveClass(contentItems, currentItem);
    });
};

tabItems.forEach(checkoutTabs);

//animation effects
AOS.init();